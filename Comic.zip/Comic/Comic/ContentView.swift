//
//  ContentView.swift
//  Comic
//
//  Created by Kavsoft on 10/12/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        TabView{
            
            Home().tabItem {
                
                Image("Home").font(.title)
            }
            
            Search().tabItem {
                
                Image("Search").font(.title)
            }
            
            Text("Favorites").tabItem {
                
                Image("Favorites").font(.title)
            }
            
            Text("user").tabItem {
                
                Image("User").font(.title)
            }
            
      }.accentColor(.black)
        .edgesIgnoringSafeArea(.top)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    
    var body : some View{
        
        ZStack{
            
            Color.black.edgesIgnoringSafeArea(.top)
            
            VStack{
                
                HStack{
                    
                    Spacer()
                    
                    Image("dc")
                    
                    Spacer()
                    
                    Button(action: {
                        
                    }) {
                        
                        Image("Menu").renderingMode(.original)
                    }
                    
                }.padding()
                
                GeometryReader{_ in
                    
                    VStack(spacing: 15){
                        
                        HStack{
                            
                            Text("For You").fontWeight(.heavy).font(.largeTitle)
                            
                            Spacer()
                            
                            ZStack{
                                
                                Capsule().fill(Color.gray)
                                
                                HStack{
                                    
                                    Capsule().fill(Color.black).frame(width: 30)
                                    Spacer()
                                }

                                
                            }.frame(width: 100, height: 5)
                            
                        }
                        
                        ForContent()
                        trendContent()
                        
                    }.padding()
                    
                }.background(Color.white)
                
            }
        }
    }
}

struct ForContent : View {
    
    var body : some View{
        
        ScrollView(.horizontal, showsIndicators: false) {
            
            HStack(spacing : 10){
                
                ForEach(foryou){i in
                    
                    
                    VStack(spacing: 10){
                        
                        Image(i.image)
                        Text(i.name).font(.body).fontWeight(.light)
                        Ratings(rating: i.rating)
                        
                    }.padding(.bottom, 15)
                    
                    
                }
            }
        }
    }
}

struct Ratings : View {
    
    var rating : Int
    
    var body : some View{
        
    
        HStack(spacing: 6){
            
            ForEach(1..<6){i in
                
                Image(systemName:"star.fill").font(.body).foregroundColor(Color.pink.opacity(self.rating >= i ? 1 : 0.5))
            }
        }
    }
}

struct trendContent : View {
    
    var body : some View{
        
        VStack(spacing: 10){
            
            HStack{
                
                Text("Trending").fontWeight(.heavy).font(.largeTitle)
                
                Spacer()
                
                ZStack{
                    
                    Capsule().fill(Color.gray)
                    
                    HStack{
                        
                        Capsule().fill(Color.black).frame(width: 40)
                        Spacer()
                    }

                    
                }.frame(width: 100, height: 5)
                
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing : 10){
                    
                    ForEach(trend){i in
                        
                        
                        VStack(spacing: 10){
                            
                            Image(i.image)
                            Text(i.name).font(.body).fontWeight(.light)
                            Ratings(rating: i.rating)
                            
                        }.padding(.bottom, 15)
                        
                        
                    }
                }
            }
            
        }
        
    }
}

struct Search : View {
    
    @State var txt = ""
    
    var body : some View{
        
        ZStack{
            
            Color.black.edgesIgnoringSafeArea(.top)
            
            VStack{
                
                HStack{
                    
                    Spacer()
                    Image("dc")
                    Spacer()
                    
                }.padding()
                
                HStack(spacing: 10){
                    
                    TextField("Search....", text: self.$txt).padding(10).foregroundColor(.white)
                    Image("search1").padding(.trailing, 12)
                    
                }.background(Color("Color"))
                .padding()
                
                
                GeometryReader{_ in
                    
                    VStack(alignment: .leading, spacing: 15){
                        
                        Recents()
                        Explore()
                        
                    }.padding()
                    
                }.background(Color.white)
            }
        }
    }
}

struct Recents : View {
    
    var body : some View{
        
        VStack(alignment: .leading,spacing : 15){
            
            Text("Recent Searches").fontWeight(.heavy).font(.title)
            
            Divider()
            
            ForEach(recents){i in
                
                HStack(spacing: 10){
                    
                    Image(i.image).frame(width: 50, height: 50).clipShape(Circle())
                    Text(i.name)
                    Spacer()
                    Button(action: {
                        
                    }) {
                        
                        Image("Delete").renderingMode(.original)
                    }
                }
            }
            
        }
    }
}

struct Explore : View {
    
    var body : some View{
        
        
        VStack(alignment: .leading,spacing: 10){
            
            HStack{
                
                Text("Explore").fontWeight(.heavy).font(.title)
                
                Spacer()
                
                Button(action: {
                    
                }) {
                    
                    Image("Arrow").renderingMode(.original)
                }
            }
            
            
            Divider()
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing : 10){
                    
                    ForEach(explore){i in
                        
                        
                        VStack(spacing: 10){
                            
                            Image(i.image)
                            Text(i.name).font(.body).fontWeight(.light)
                            
                        }.padding(.bottom, 15)
                        
                        
                    }
                }
            }
        }

    }
}

// i already implemeted a sample data.....
// tab view color is not changing may be its a bug....


struct RecentsDatatype : Identifiable {
    
    var id : Int
    var name : String
    var image : String
}

var recents = [RecentsDatatype(id: 0, name: "Wonder Woman",image: "r1"),
              RecentsDatatype(id: 1, name: "Batman",image: "r2"),
              RecentsDatatype(id: 2, name: "SuperMan",image: "r3")]

struct exploredatatype : Identifiable {
    
    var id : Int
    var name : String
    var image : String
}

var explore = [exploredatatype(id: 0, name: "Cat Woman",image: "e1"),
              exploredatatype(id: 1, name: "Flash Reborn",image: "e2"),
              exploredatatype(id: 2, name: "UThor",image: "e3")]

struct fordatatype : Identifiable{
    
    var id : Int
    var name : String
    var image : String
    var rating : Int
}

var foryou = [fordatatype(id: 0,name: "BatMan",image: "f1", rating: 4),
              fordatatype(id: 1,name: "Future Ends",image: "f2", rating: 5),
              fordatatype(id: 2,name: "Dark Detective",image: "f3", rating: 4)]


struct trenddatatype : Identifiable{
    
    var id : Int
    var name : String
    var image : String
    var rating : Int
}

var trend = [trenddatatype(id: 0,name: "Final Crisis",image: "t1", rating: 5),
             trenddatatype(id: 1,name: "Aqua Man",image: "t2", rating: 4),
             trenddatatype(id: 2,name: "Justice League",image: "t3", rating: 4)]
